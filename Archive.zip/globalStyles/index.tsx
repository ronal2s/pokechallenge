import { StyleSheet } from "react-native";
const PRIMARY_COLOR = "#CC0000";

export default StyleSheet.create({
    headerHome: {
        backgroundColor: PRIMARY_COLOR,
    }
})