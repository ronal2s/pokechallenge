import { StyleSheet } from "react-native";

export default StyleSheet.create({
    subtitle: {
        textAlign: "left",
        fontSize: 22,
        fontWeight: "200"
    },
    lightFont: {
        fontWeight: "100"
    },
    spriteContainerRed: {
        borderWidth: 1,
        borderColor: "#3B4CCA",
        backgroundColor: "#CC0000",
        height: 80,
        width: 80,
        borderRadius: 100 / 2,
        justifyContent: "center",
        alignItems: "center"
    },
    spriteContainerBlue: {
        borderWidth: 1,
        borderColor: "#CC0000",
        backgroundColor: "#3B4CCA",
        height: 80,
        width: 80,
        borderRadius: 100 / 2,
        justifyContent: "center",
        alignItems: "center"
    },
    imagesContainer: {
        flexWrap: "wrap", 
        flexDirection: "row", 
        justifyContent: "space-around"
    }
})