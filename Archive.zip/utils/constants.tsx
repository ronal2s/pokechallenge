const URL_API = "https://pokeapi.co/api/v2";

export {
    URL_API
}